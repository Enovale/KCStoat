## KCStoat

A mod that replaces the kaycee's mod exclusive normal stoat in your deck with the talking stoat from Act 1.
It also tweaks the stoat so that it doesn't interrupt you when you draw it when in a Kaycee's run unless you are fighting the prospector.

# Issues
This mod will not replace the existing shitty stoat in your deck. It will take effect once you start a new run. (Make sure you don't end your run before the first boss!)
